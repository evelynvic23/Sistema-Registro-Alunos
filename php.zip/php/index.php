<?php include 'header.php';?>


  <div class="card" style="width:500px">
    <img class="card-img-top" src="imagens/alunos.png" alt="Card image" style="width:100%" height="420px">
    <div class="card-body">
     
      <a href="form_login_sge.php" class="btn btn-primary" id="b1">Acessar sua conta</a>
      <a href="form.php" class="btn btn-primary" id="b2">Cadastre-se</a>

    </div>
  </div>

<?php include 'footer.php';?>

