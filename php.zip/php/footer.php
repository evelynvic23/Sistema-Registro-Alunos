
    <footer>
        <p>Todos os direitos reservados - Evelyn® 2024</p>
    </footer>
    
</body>
</html>